  <!--begin::Base Scripts -->
  <script src="assets/vendors/base/vendors.bundle.js" type="text/javascript"></script>
  <script src="assets/demo/default/base/scripts.bundle.js" type="text/javascript"></script>
  <!--end::Base Scripts -->
  <!--begin::Page Snippets -->
  <script src="assets/snippets/custom/pages/user/login.js" type="text/javascript"></script>
  <!--end::Page Snippets -->
  <!-- Bootstrap scripts -->
  <!-- <script src="js/bootstrap/bootstrap.min.js"></script> -->
<body>
</html>
