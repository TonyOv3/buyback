<?php
$file_name="chat";

//Header section
require_once("include/header.php");

//Template file
require_once("views/chat-customer.php");
 ?>
