<?php
$file_name="promocode";

//Header section
require_once("include/header.php");

//Template file
require_once("views/promocode/add_promocode.php");

//Footer section
// require_once("include/footer.php"); ?>
