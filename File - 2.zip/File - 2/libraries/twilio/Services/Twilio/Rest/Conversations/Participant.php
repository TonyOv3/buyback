<?php

class Services_Twilio_Rest_Conversations_Participant extends
    Services_Twilio_ConversationsInstanceResource {

}
