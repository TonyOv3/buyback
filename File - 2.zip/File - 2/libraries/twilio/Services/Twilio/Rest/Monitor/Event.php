<?php

class Services_Twilio_Rest_Monitor_Event extends Services_Twilio_MonitorInstanceResource {

}
